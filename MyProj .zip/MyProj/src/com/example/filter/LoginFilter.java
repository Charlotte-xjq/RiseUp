package com.example.filter;

import javax.servlet.*;
import javax.servlet.http.*;
import java.io.IOException;

public class LoginFilter implements Filter {
    
    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {
        HttpServletRequest req = (HttpServletRequest) request;
        HttpServletResponse resp = (HttpServletResponse) response;
        HttpSession session = req.getSession();
        
        String path = req.getRequestURI();
        
        // 如果是登录相关页面或资源,直接放行
        if (path.endsWith("login.jsp") || path.endsWith("register.jsp") 
                || path.contains("/css/") || path.contains("/js/") 
                || path.contains("/images/") || path.endsWith("/user")) {
            chain.doFilter(request, response);
            return;
        }
        
        // 检查是否已登录
        if (session.getAttribute("user") == null) {
            resp.sendRedirect(req.getContextPath() + "/login.jsp");
            return;
        }
        
        // 检查管理员权限
        if (path.startsWith(req.getContextPath() + "/admin/")) {
            Integer role = (Integer) session.getAttribute("role");
            if (role == null || role != 1) {
                resp.sendRedirect(req.getContextPath() + "/concert?action=list");
                return;
            }
        }
        
        chain.doFilter(request, response);
    }
    
    @Override
    public void init(FilterConfig filterConfig) throws ServletException {}
    
    @Override
    public void destroy() {}
} 