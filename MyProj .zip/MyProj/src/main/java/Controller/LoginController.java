package Controller;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

import vo.LoginUser;
import model.UserModel;
/**
 * Servlet implementation class LoginServlet
 */
@WebServlet("/LoginCotroller")

public class LoginController extends HttpServlet{

	private static final long serialVersionUID = 1L;
    
    /**
     * @see HttpServlet#HttpServlet()
     */
    public LoginController() {
        super();
        // TODO Auto-generated constructor stub
    }

	/**
	 * @see HttpServlet#doGet(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		doPost(request, response);
	}
	/**
	 * @see HttpServlet#doPost(HttpServletRequest request, HttpServletResponse response)
	 */
	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		// TODO Auto-generated method stub
		request.setCharacterEncoding("utf-8");
		String username = request.getParameter("username");
		String password = request.getParameter("password");
		LoginUser usrname = new LoginUser();
		
		usrname.setName(username);
		
		usrname.setPwd(password);
		UserModel ub = new UserModel();
		if(ub.validate(usrname)) {
			HttpSession session = request.getSession(true);
			session.setAttribute("curUser", usrname.getName());//将登录用户信息保存在session中
			request.setAttribute("user",usrname); //将用户信息保存在request中，传给转发的页面
		    RequestDispatcher dis = request.getRequestDispatcher("welocome.jsp");
		    dis.forward(request, response);
		} else {
			response.sendRedirect("login.jsp");
		}
	}
	
	
	
}
