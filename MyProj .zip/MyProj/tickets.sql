/*
 Navicat Premium Dump SQL

 Source Server         : mysqlDB
 Source Server Type    : MySQL
 Source Server Version : 80037 (8.0.37)
 Source Host           : localhost:3306
 Source Schema         : tickets

 Target Server Type    : MySQL
 Target Server Version : 80037 (8.0.37)
 File Encoding         : 65001

 Date: 14/12/2024 02:05:59
*/

SET NAMES utf8mb4;
SET FOREIGN_KEY_CHECKS = 0;

-- ----------------------------
-- Table structure for comments
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `concertId` int NOT NULL,
  `content` text CHARACTER SET utf8mb3 COLLATE utf8mb3_general_ci NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `idx_concert_id`(`concertId`) USING BTREE,
  INDEX `idx_user_id`(`userId`) USING BTREE
) ENGINE = MyISAM AUTO_INCREMENT = 1 CHARACTER SET = utf8mb3 COLLATE = utf8mb3_general_ci ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of comments
-- ----------------------------

-- ----------------------------
-- Table structure for concerts
-- ----------------------------
DROP TABLE IF EXISTS `concerts`;
CREATE TABLE `concerts`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `name` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `date` date NOT NULL,
  `location` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `ticketPrice` decimal(10, 2) NOT NULL,
  `image` varchar(200) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `remainingTickets` int NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 9 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of concerts
-- ----------------------------
INSERT INTO `concerts` VALUES (1, '周杰伦2024巡回演唱会', '2024-06-01', '北京鸟巢', 1288.00, 'concert1.jpg', 1000, '2024-12-14 01:59:28');
INSERT INTO `concerts` VALUES (2, '林俊杰《圣所》世界巡回演唱会', '2024-07-15', '上海梅赛德斯奔驰文化中心', 888.00, 'concert2.jpg', 800, '2024-12-14 01:59:28');
INSERT INTO `concerts` VALUES (3, '张学友2024演唱会', '2024-08-30', '广州天河体育中心', 1088.00, 'concert3.jpg', 1200, '2024-12-14 01:59:28');
INSERT INTO `concerts` VALUES (4, '陈奕迅FEAR AND DREAMS演唱会', '2024-09-20', '深圳湾体育中心', 988.00, 'concert4.jpg', 900, '2024-12-14 01:59:28');
INSERT INTO `concerts` VALUES (5, '五月天2024诺亚方舟巡回演唱会', '2024-10-01', '南京奥林匹克体育中心', 899.00, 'concert5.jpg', 1500, '2024-12-14 01:59:28');
INSERT INTO `concerts` VALUES (6, 'Taylor Swift The Eras Tour', '2024-11-15', '上海梅赛德斯奔驰文化中心', 1688.00, 'concert6.jpg', 2000, '2024-12-14 01:59:28');

-- ----------------------------
-- Table structure for orders
-- ----------------------------
DROP TABLE IF EXISTS `orders`;
CREATE TABLE `orders`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `concertId` int NOT NULL,
  `quantity` int NOT NULL,
  `totalPrice` decimal(10, 2) NOT NULL,
  `status` int NOT NULL,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  INDEX `userId`(`userId` ASC) USING BTREE,
  INDEX `concertId`(`concertId` ASC) USING BTREE,
  CONSTRAINT `orders_ibfk_1` FOREIGN KEY (`userId`) REFERENCES `users` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT,
  CONSTRAINT `orders_ibfk_2` FOREIGN KEY (`concertId`) REFERENCES `concerts` (`id`) ON DELETE RESTRICT ON UPDATE RESTRICT
) ENGINE = InnoDB AUTO_INCREMENT = 7 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of orders
-- ----------------------------
INSERT INTO `orders` VALUES (1, 2, 1, 2, 2576.00, 2, '2024-12-14 01:59:28');
INSERT INTO `orders` VALUES (2, 2, 3, 1, 1088.00, 1, '2024-12-14 01:59:28');
INSERT INTO `orders` VALUES (3, 3, 2, 3, 2664.00, 2, '2024-12-14 01:59:28');
INSERT INTO `orders` VALUES (4, 3, 4, 2, 1976.00, 3, '2024-12-14 01:59:28');
INSERT INTO `orders` VALUES (5, 2, 5, 4, 3596.00, 1, '2024-12-14 01:59:28');
INSERT INTO `orders` VALUES (6, 3, 6, 1, 1688.00, 2, '2024-12-14 01:59:28');

-- ----------------------------
-- Table structure for users
-- ----------------------------
DROP TABLE IF EXISTS `users`;
CREATE TABLE `users`  (
  `id` int NOT NULL AUTO_INCREMENT,
  `username` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `password` varchar(50) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NOT NULL,
  `email` varchar(100) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `phoneNumber` varchar(20) CHARACTER SET utf8mb4 COLLATE utf8mb4_bin NULL DEFAULT NULL,
  `role` int NULL DEFAULT 0,
  `create_time` timestamp NULL DEFAULT CURRENT_TIMESTAMP,
  PRIMARY KEY (`id`) USING BTREE,
  UNIQUE INDEX `idx_username_unique`(`username` ASC) USING BTREE
) ENGINE = InnoDB AUTO_INCREMENT = 4 CHARACTER SET = utf8mb4 COLLATE = utf8mb4_bin ROW_FORMAT = Dynamic;

-- ----------------------------
-- Records of users
-- ----------------------------
INSERT INTO `users` VALUES (1, 'admin', 'admin123', 'admin@example.com', '13800000000', 1, '2024-12-14 01:59:28');
INSERT INTO `users` VALUES (2, 'user1', 'user123', 'user1@example.com', '13800000001', 0, '2024-12-14 01:59:28');
INSERT INTO `users` VALUES (3, 'user2', 'user123', 'user2@example.com', '13800000002', 0, '2024-12-14 01:59:28');

SET FOREIGN_KEY_CHECKS = 1;
