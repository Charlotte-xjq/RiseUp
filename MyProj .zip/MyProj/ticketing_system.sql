/*
Navicat MySQL Data Transfer

Source Server         : ConcertBookingDB
Source Server Version : 80300
Source Host           : localhost:3306
Source Database       : ticketing_system

Target Server Type    : MYSQL
Target Server Version : 80300
File Encoding         : 65001

Date: 2024-10-26 22:42:25
*/

SET FOREIGN_KEY_CHECKS=0;

-- 创建数据库
CREATE DATABASE IF NOT EXISTS ticketing_system DEFAULT CHARACTER SET utf8mb4;

USE ticketing_system;

-- 创建用户表
CREATE TABLE IF NOT EXISTS users (
    id INT PRIMARY KEY AUTO_INCREMENT,
    username VARCHAR(50) NOT NULL,
    password VARCHAR(50) NOT NULL,
    email VARCHAR(100),
    phoneNumber VARCHAR(20),
    role INT DEFAULT 0,  -- 0: 普通用户, 1: 管理员
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    UNIQUE KEY idx_username_unique (username)
);

-- 创建演唱会表
CREATE TABLE IF NOT EXISTS concerts (
    id INT PRIMARY KEY AUTO_INCREMENT,
    name VARCHAR(100) NOT NULL,
    date DATE NOT NULL,
    location VARCHAR(200) NOT NULL,
    ticketPrice DECIMAL(10,2) NOT NULL,
    image VARCHAR(200),
    remainingTickets INT NOT NULL,
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- 删除原有的订单表
DROP TABLE IF EXISTS orders;

-- 重新创建订单表（带有级联删除）
CREATE TABLE orders (
    id INT PRIMARY KEY AUTO_INCREMENT,
    userId INT NOT NULL,
    concertId INT NOT NULL,
    quantity INT NOT NULL,
    totalPrice DECIMAL(10,2) NOT NULL,
    status INT NOT NULL,  -- 1: 待支付, 2: 已支付, 3: 已取消
    create_time TIMESTAMP DEFAULT CURRENT_TIMESTAMP,
    FOREIGN KEY (userId) REFERENCES users(id) ON DELETE CASCADE,
    FOREIGN KEY (concertId) REFERENCES concerts(id) ON DELETE CASCADE
);

-- 插入测试数据
-- 插入用户
INSERT INTO users (username, password, email, phoneNumber, role) VALUES
('admin', 'admin123', 'admin@example.com', '13800000000', 1),
('user1', 'user123', 'user1@example.com', '13800000001', 0),
('user2', 'user123', 'user2@example.com', '13800000002', 0);

-- 插入演唱会
INSERT INTO concerts (name, date, location, ticketPrice, image, remainingTickets) VALUES
('周杰伦2024巡回演唱会', '2024-06-01', '北京鸟巢', 1288.00, 'concert1.jpg', 1000),
('林俊杰《圣所》世界巡回演唱会', '2024-07-15', '上海梅赛德斯奔驰文化中心', 888.00, 'concert2.jpg', 800),
('张学友2024演唱会', '2024-08-30', '广州天河体育中心', 1088.00, 'concert3.jpg', 1200),
('陈奕迅FEAR AND DREAMS演唱会', '2024-09-20', '深圳湾体育中心', 988.00, 'concert4.jpg', 900),
('五月天2024诺亚方舟巡回演唱会', '2024-10-01', '南京奥林匹克体育中心', 899.00, 'concert5.jpg', 1500),
('Taylor Swift The Eras Tour', '2024-11-15', '上海梅赛德斯奔驰文化中心', 1688.00, 'concert6.jpg', 2000),('Taylor Swift The Eras Tour', '2024-11-15', '上海梅赛德斯奔驰文化中心', 1688.00, 'concert6.jpg', 2000),('Taylor Swift The Eras Tour', '2024-11-15', '上海梅赛德斯奔驰文化中心', 1688.00, 'concert6.jpg', 2000);

-- 插入订单
INSERT INTO orders (userId, concertId, quantity, totalPrice, status) VALUES
(2, 1, 2, 2576.00, 2),  -- user1购买了2张周杰伦的票并已支付
(2, 3, 1, 1088.00, 1),  -- user1购买了1张张学友的票待支付
(3, 2, 3, 2664.00, 2),  -- user2购买了3张林俊杰的票并已支付
(3, 4, 2, 1976.00, 3),  -- user2购买了2张陈奕迅的票但已取消
(2, 5, 4, 3596.00, 1),  -- user1购买了4张五月天的票待支付
(3, 6, 1, 1688.00, 2);  -- user2购买了1张Taylor Swift的票并已支付

-- ----------------------------
-- Table structure for `comments`
-- ----------------------------
DROP TABLE IF EXISTS `comments`;
CREATE TABLE `comments` (
  `id` int NOT NULL AUTO_INCREMENT,
  `userId` int NOT NULL,
  `concertId` int NOT NULL,
  `content` text NOT NULL,
  `createTime` datetime NOT NULL,
  PRIMARY KEY (`id`),
  KEY `idx_concert_id` (`concertId`),
  KEY `idx_user_id` (`userId`)
) ENGINE=MyISAM DEFAULT CHARSET=utf8mb3;
